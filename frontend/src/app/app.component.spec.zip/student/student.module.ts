import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { StudentRoutingModule } from './student-routing.module';
import { IonicModule } from '@ionic/angular';
import { CourseListComponent } from './course-list/course-list.component';
import { FormsModule } from '@angular/forms';


@NgModule({
  declarations: [CourseListComponent],
  imports: [
    CommonModule,
    StudentRoutingModule,
    IonicModule.forRoot(),
    FormsModule,
    
  ]
})
export class StudentModule { }
