import { Component, OnInit, ViewChild } from '@angular/core';
import { IonModal } from '@ionic/angular';
import { OverlayEventDetail } from '@ionic/core/components';

@Component({
  selector: 'app-course-list',
  templateUrl: './course-list.component.html',
  styleUrls: ['./course-list.component.scss'],
})
export class CourseListComponent implements OnInit {

  courseList:any;
 courseName:any;
  courseId:any;

  @ViewChild(IonModal)
  modal!: IonModal;

  message = 'This modal example uses triggers to automatically open a modal when the button is clicked.';
  name: string | undefined;

  cancel() {
    this.modal.dismiss(null, 'cancel');
  }

  confirm() {
    this.modal.dismiss(this.name, 'confirm');
  }

  onWillDismiss(event: Event) {
    const ev = event as CustomEvent<OverlayEventDetail<string>>;
    if (ev.detail.role === 'confirm') {
      this.message = `Hello, ${ev.detail.data}!`;
    }
  }

  constructor() { }

  ngOnInit() {
    this.courseList=[
      { id: "12345", courseName: 'MEAN STACK', fees:12000, teacher: "Sanket Jagtap" },
      { id: "123456", courseName: 'MERN STACK', fees:12000, teacher: "Sanket Jagtap" },
      { id: "12336", courseName: 'FULL STACK', fees:12000, teacher: "Sanket Jagtap" },
      { id: "123465", courseName: 'JAVA', fees:12000, teacher: "Sanket Jagtap" }
  ]
  }

  getId(data:any){
    console.log(data)
    this.courseName=data
  }

}
