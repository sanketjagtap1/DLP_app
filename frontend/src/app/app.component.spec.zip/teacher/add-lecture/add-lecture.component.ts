import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-lecture',
  templateUrl: './add-lecture.component.html',
  styleUrls: ['./add-lecture.component.scss'],
})
export class AddLectureComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
