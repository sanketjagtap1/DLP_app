import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manage-lecture',
  templateUrl: './manage-lecture.component.html',
  styleUrls: ['./manage-lecture.component.scss'],
})
export class ManageLectureComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
